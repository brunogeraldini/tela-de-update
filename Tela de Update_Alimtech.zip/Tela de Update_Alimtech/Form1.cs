﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Tela_de_Update_Alimtech
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Inicializando a ComboBox, mas sem itens inicialmente.
            cbb_mes.DropDownStyle = ComboBoxStyle.DropDownList;  // Impede a edição manual
            cbb_mes.DropDownStyle = ComboBoxStyle.DropDownList;  // Impede a edição manual.SelectedIndexChanged += new EventHandler(comboBox1_SelectedIndexChanged);
        }

        // Evento de clique no ComboBox para adicionar os números de 1 a 31
        private void comboBox1_Click(object sender, EventArgs e)
        {
            // Verifica se a ComboBox já foi preenchida
            if (cbb_mes.DropDownStyle = ComboBoxStyle.DropDownList;  // Impede a edição manual.Items.Count == 0)
            {
                // Limpa os itens antigos (caso tenha)
                cbb_mes.Items.Clear();

                // Adiciona os números de 1 a 31 na ComboBox
                for (int i = 1; i <= 31; i++)
                {
                    cbb_mes.Items.Add(i.ToString());
                }
            }
        }

        // Evento quando o usuário seleciona um item
        private void cbb_mes_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Exibe o número selecionado em uma MessageBox
            if (cbb_mes.SelectedIndex != -1)
            {
                MessageBox.Show($"Você selecionou o dia: {cbb_mes.SelectedItem}");
            }
        }
    }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void click_mes_cbb(object sender, MouseEventArgs e)
        {
            
        }

        private void click_dia_cbb(object sender, MouseEventArgs e)
        {

        }

        private void mostra_txb_clientes(object sender, EventArgs e)
        {

        }
    }
}
