﻿namespace Tela_de_Update_Alimtech
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txb_data = new System.Windows.Forms.TextBox();
            this.cbb_dia = new System.Windows.Forms.ComboBox();
            this.cbb_mes = new System.Windows.Forms.ComboBox();
            this.txb_clientes = new System.Windows.Forms.TextBox();
            this.txb_qtd_de_clientes = new System.Windows.Forms.TextBox();
            this.txb_titulo = new System.Windows.Forms.TextBox();
            this.txb_ingr_utiliz = new System.Windows.Forms.TextBox();
            this.txb_ingredientes = new System.Windows.Forms.TextBox();
            this.txb_quantidade = new System.Windows.Forms.TextBox();
            this.cbb1_ingred = new System.Windows.Forms.ComboBox();
            this.cbb2_ingred = new System.Windows.Forms.ComboBox();
            this.cbb1_qtd = new System.Windows.Forms.ComboBox();
            this.cbb2_qtd = new System.Windows.Forms.ComboBox();
            this.btt_atualizar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txb_data
            // 
            this.txb_data.BackColor = System.Drawing.Color.Bisque;
            this.txb_data.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txb_data.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_data.Location = new System.Drawing.Point(159, 99);
            this.txb_data.Name = "txb_data";
            this.txb_data.Size = new System.Drawing.Size(100, 28);
            this.txb_data.TabIndex = 0;
            this.txb_data.Text = "Data:";
            this.txb_data.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txb_data.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // cbb_dia
            // 
            this.cbb_dia.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbb_dia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_dia.FormattingEnabled = true;
            this.cbb_dia.Location = new System.Drawing.Point(340, 100);
            this.cbb_dia.Name = "cbb_dia";
            this.cbb_dia.Size = new System.Drawing.Size(121, 32);
            this.cbb_dia.TabIndex = 1;
            this.cbb_dia.Text = "Dia: ";
            this.cbb_dia.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.cbb_dia.MouseClick += new System.Windows.Forms.MouseEventHandler(this.click_dia_cbb);
            // 
            // cbb_mes
            // 
            this.cbb_mes.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbb_mes.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb_mes.FormattingEnabled = true;
            this.cbb_mes.Location = new System.Drawing.Point(522, 100);
            this.cbb_mes.Name = "cbb_mes";
            this.cbb_mes.Size = new System.Drawing.Size(121, 32);
            this.cbb_mes.TabIndex = 2;
            this.cbb_mes.Text = "Mês: ";
            this.cbb_mes.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            this.cbb_mes.MouseClick += new System.Windows.Forms.MouseEventHandler(this.click_mes_cbb);
            // 
            // txb_clientes
            // 
            this.txb_clientes.BackColor = System.Drawing.Color.Bisque;
            this.txb_clientes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txb_clientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_clientes.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_clientes.Location = new System.Drawing.Point(180, 182);
            this.txb_clientes.Name = "txb_clientes";
            this.txb_clientes.Size = new System.Drawing.Size(194, 28);
            this.txb_clientes.TabIndex = 3;
            this.txb_clientes.Text = "Clientes do dia: ";
            // 
            // txb_qtd_de_clientes
            // 
            this.txb_qtd_de_clientes.BackColor = System.Drawing.Color.Gainsboro;
            this.txb_qtd_de_clientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_qtd_de_clientes.ForeColor = System.Drawing.SystemColors.WindowText;
            this.txb_qtd_de_clientes.Location = new System.Drawing.Point(424, 182);
            this.txb_qtd_de_clientes.Name = "txb_qtd_de_clientes";
            this.txb_qtd_de_clientes.Size = new System.Drawing.Size(194, 35);
            this.txb_qtd_de_clientes.TabIndex = 4;
            this.txb_qtd_de_clientes.TextChanged += new System.EventHandler(this.mostra_txb_clientes);
            // 
            // txb_titulo
            // 
            this.txb_titulo.BackColor = System.Drawing.Color.Bisque;
            this.txb_titulo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txb_titulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_titulo.Location = new System.Drawing.Point(295, 12);
            this.txb_titulo.Name = "txb_titulo";
            this.txb_titulo.Size = new System.Drawing.Size(194, 37);
            this.txb_titulo.TabIndex = 5;
            this.txb_titulo.Text = "Update";
            this.txb_titulo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txb_ingr_utiliz
            // 
            this.txb_ingr_utiliz.BackColor = System.Drawing.Color.Bisque;
            this.txb_ingr_utiliz.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txb_ingr_utiliz.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_ingr_utiliz.Location = new System.Drawing.Point(253, 271);
            this.txb_ingr_utiliz.Name = "txb_ingr_utiliz";
            this.txb_ingr_utiliz.Size = new System.Drawing.Size(290, 28);
            this.txb_ingr_utiliz.TabIndex = 6;
            this.txb_ingr_utiliz.Text = "Ingredientes Utilizados";
            this.txb_ingr_utiliz.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txb_ingredientes
            // 
            this.txb_ingredientes.BackColor = System.Drawing.Color.Bisque;
            this.txb_ingredientes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txb_ingredientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_ingredientes.Location = new System.Drawing.Point(65, 348);
            this.txb_ingredientes.Name = "txb_ingredientes";
            this.txb_ingredientes.Size = new System.Drawing.Size(194, 28);
            this.txb_ingredientes.TabIndex = 7;
            this.txb_ingredientes.Text = "Ingredientes:";
            this.txb_ingredientes.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txb_quantidade
            // 
            this.txb_quantidade.BackColor = System.Drawing.Color.Bisque;
            this.txb_quantidade.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txb_quantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_quantidade.Location = new System.Drawing.Point(522, 348);
            this.txb_quantidade.Name = "txb_quantidade";
            this.txb_quantidade.Size = new System.Drawing.Size(194, 28);
            this.txb_quantidade.TabIndex = 8;
            this.txb_quantidade.Text = "Quantidade:";
            this.txb_quantidade.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cbb1_ingred
            // 
            this.cbb1_ingred.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbb1_ingred.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb1_ingred.FormattingEnabled = true;
            this.cbb1_ingred.Location = new System.Drawing.Point(65, 412);
            this.cbb1_ingred.Name = "cbb1_ingred";
            this.cbb1_ingred.Size = new System.Drawing.Size(194, 32);
            this.cbb1_ingred.TabIndex = 9;
            // 
            // cbb2_ingred
            // 
            this.cbb2_ingred.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbb2_ingred.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb2_ingred.FormattingEnabled = true;
            this.cbb2_ingred.Location = new System.Drawing.Point(65, 462);
            this.cbb2_ingred.Name = "cbb2_ingred";
            this.cbb2_ingred.Size = new System.Drawing.Size(194, 32);
            this.cbb2_ingred.TabIndex = 10;
            // 
            // cbb1_qtd
            // 
            this.cbb1_qtd.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbb1_qtd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb1_qtd.FormattingEnabled = true;
            this.cbb1_qtd.Location = new System.Drawing.Point(522, 412);
            this.cbb1_qtd.Name = "cbb1_qtd";
            this.cbb1_qtd.Size = new System.Drawing.Size(194, 32);
            this.cbb1_qtd.TabIndex = 11;
            // 
            // cbb2_qtd
            // 
            this.cbb2_qtd.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.cbb2_qtd.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbb2_qtd.FormattingEnabled = true;
            this.cbb2_qtd.Location = new System.Drawing.Point(522, 462);
            this.cbb2_qtd.Name = "cbb2_qtd";
            this.cbb2_qtd.Size = new System.Drawing.Size(194, 32);
            this.cbb2_qtd.TabIndex = 12;
            // 
            // btt_atualizar
            // 
            this.btt_atualizar.BackColor = System.Drawing.Color.LimeGreen;
            this.btt_atualizar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_atualizar.Location = new System.Drawing.Point(340, 583);
            this.btt_atualizar.Name = "btt_atualizar";
            this.btt_atualizar.Size = new System.Drawing.Size(95, 27);
            this.btt_atualizar.TabIndex = 13;
            this.btt_atualizar.Text = "Atualizar";
            this.btt_atualizar.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(800, 622);
            this.Controls.Add(this.btt_atualizar);
            this.Controls.Add(this.cbb2_qtd);
            this.Controls.Add(this.cbb1_qtd);
            this.Controls.Add(this.cbb2_ingred);
            this.Controls.Add(this.cbb1_ingred);
            this.Controls.Add(this.txb_quantidade);
            this.Controls.Add(this.txb_ingredientes);
            this.Controls.Add(this.txb_ingr_utiliz);
            this.Controls.Add(this.txb_titulo);
            this.Controls.Add(this.txb_qtd_de_clientes);
            this.Controls.Add(this.txb_clientes);
            this.Controls.Add(this.cbb_mes);
            this.Controls.Add(this.cbb_dia);
            this.Controls.Add(this.txb_data);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txb_data;
        private System.Windows.Forms.ComboBox cbb_dia;
        private System.Windows.Forms.ComboBox cbb_mes;
        private System.Windows.Forms.TextBox txb_clientes;
        private System.Windows.Forms.TextBox txb_qtd_de_clientes;
        private System.Windows.Forms.TextBox txb_titulo;
        private System.Windows.Forms.TextBox txb_ingr_utiliz;
        private System.Windows.Forms.TextBox txb_ingredientes;
        private System.Windows.Forms.TextBox txb_quantidade;
        private System.Windows.Forms.ComboBox cbb1_ingred;
        private System.Windows.Forms.ComboBox cbb2_ingred;
        private System.Windows.Forms.ComboBox cbb1_qtd;
        private System.Windows.Forms.ComboBox cbb2_qtd;
        private System.Windows.Forms.Button btt_atualizar;
    }
}

